from flask import Flask, request, jsonify, render_template, redirect
import os
from checkout_sdk.checkout_sdk import CheckoutSdk
from checkout_sdk.environment import Environment
from checkout_sdk.payments.payments import PaymentRequest
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

app = Flask(__name__)

# Initialize Flow SDK
sdk = CheckoutSdk.builder() \
    .secret_key(os.getenv('SECRET_KEY')) \
    .environment(Environment.sandbox()) \
    .build()

@app.route('/')
def home():
    return redirect('/checkout')  # Redirect to your checkout page or display a welcome message

@app.route('/checkout')
def checkout():
    return render_template('checkout.html')

@app.route('/submit-payment', methods=['POST'])
def submit_payment():
    try:
        data = request.form  # Get form data
        print("Form Data Received:", data)  # Log form data for debugging

        # Validate form data
        if not all(key in data for key in ['card-number', 'expiry-date', 'cvv', 'cardholder-name', 'card-type']):
            return "Missing form data. Please fill in all fields.", 400

        # Parse expiry date (MM/YYYY)
        expiry_month, expiry_year = data['expiry-date'].split('/')
        if not expiry_month.isdigit() or not expiry_year.isdigit() or len(expiry_year) != 4:
            return "Invalid expiry date format. Please use MM/YYYY.", 400

        # Create payment request
        payment_request = {
            "source": {
                "type": "card",
                "number": data['card-number'],
                "expiry_month": int(expiry_month),
                "expiry_year": int(expiry_year),
                "cvv": data['cvv'],
                "name": data['cardholder-name']
            },
            "amount": 5000,  # $50.00 in cents
            "currency": "USD",
            "processing_channel_id": os.getenv('PROCESSING_CHANNEL_ID'),
            "3ds": {
                "enabled": True
            }
        }

        # Send payment request
        payment_response = sdk.payments.request_payment(payment_request)
        if payment_response.id:
            return redirect(f"/payment-success?payment_id={payment_response.id}&last4={data['card-number'][-4:]}&card_type={data['card-type']}")
        else:
            return "Payment failed. Please try again.", 400
    except Exception as e:
        print("Error:", str(e))  # Log the error for debugging
        return f"An error occurred: {str(e)}", 400

@app.route('/create-payment', methods=['POST'])
def create_payment():
    try:
        data = request.json
        payment_request = PaymentRequest(
            source={
                "type": "card",
                "number": data['cardNumber'],
                "expiry_month": int(data['expiryMonth']),
                "expiry_year": int(data['expiryYear']),
                "cvv": data['cvv'],
                "name": data['cardholderName']
            },
            amount=5000,  # $50.00 in cents
            currency="USD",
            processing_channel_id=os.getenv('PROCESSING_CHANNEL_ID'),
            three_ds={
                "enabled": True
            }
        )
        payment_response = sdk.payments.request_payment(payment_request)
        return jsonify(payment_response)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/payment-success', methods=['GET'])
def payment_success():
    payment_id = request.args.get('payment_id')
    last4 = request.args.get('last4')
    card_type = request.args.get('card_type')
    return render_template('success.html', payment_id=payment_id, last4=last4, card_type=card_type)

if __name__ == '__main__':
    app.run(debug=True)